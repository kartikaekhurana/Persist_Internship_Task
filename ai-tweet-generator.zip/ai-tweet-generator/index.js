const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
const port = 3000;

const huggingFaceApiKey = process.env.HUGGINGFACE_API_KEY;

app.use(cors());
app.use(express.json());

// Route to generate a tweet using AI
app.get('/generate-tweet', async (req, res) => {
    try {
        const response = await axios.post(
            'https://api-inference.huggingface.co/models/gpt2',
            {
                inputs: "Write a creative tweet about AI and technology in 2024."
            },
            {
                headers: { Authorization: `Bearer ${huggingFaceApiKey}` }
            }
        );
        const generatedTweet = response.data[0]?.generated_text || "AI couldn't generate a tweet.";
        res.json({ tweet: generatedTweet });
    } catch (error) {
        console.error('Error generating tweet:', error.response ? error.response.data : error.message);
        res.status(500).send("Error generating tweet.");
    }
});

// Route to post a tweet on Twitter (using Twitter API)
app.post('/post-tweet', async (req, res) => {
    const tweet = req.body.tweet;

    const twitterApiKey = process.env.TWITTER_API_KEY;
    const twitterApiSecretKey = process.env.TWITTER_API_SECRET_KEY;
    const twitterAccessToken = process.env.TWITTER_ACCESS_TOKEN;
    const twitterAccessTokenSecret = process.env.TWITTER_ACCESS_TOKEN_SECRET;

    // Integrate Twitter API to post the tweet (using Twitter's package or custom logic)
    // Placeholder for actual Twitter post logic

    res.json({ message: 'Tweet posted successfully!' });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
